import json
import boto3
import pg8000.dbapi as pg8000
import os
import uuid
import time
from datetime import datetime, timezone
from urllib.parse import unquote_plus

# -------------------------
# Environment Variables
# -------------------------
DB_HOST = os.environ.get('DB_HOST')
DB_NAME = os.environ.get('DB_NAME')
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_PORT = int(os.environ.get('DB_PORT', 5432))

# Single S3 bucket with folders
S3_BUCKET = os.environ.get('S3_BUCKET', 'weather-data-raw-sch')
RAW_FOLDER = 'raw/'
CLEAN_FOLDER = 'clean/'

s3_client = boto3.client('s3')


# -------------------------
# Lambda Handler
# -------------------------
def lambda_handler(event, context):
    print("=== Lambda 2: Transform & Load Started ===")
    start_time = time.time()

    # -------------------------
    # Parse S3 Event
    # -------------------------
    try:
        s3_event = event['Records'][0]['s3']
        source_bucket = s3_event['bucket']['name']
        file_key = unquote_plus(s3_event['object']['key'])
        print(f"Processing file: s3://{source_bucket}/{file_key}")
    except KeyError as e:
        error_msg = f"Error parsing S3 event: {e}"
        print(error_msg)
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid S3 event format', 'details': str(e)})
        }

    # -------------------------
    # Read Raw JSON from S3
    # -------------------------
    try:
        response = s3_client.get_object(Bucket=source_bucket, Key=file_key)
        raw_data = json.loads(response['Body'].read().decode('utf-8'))
        print("✓ Successfully read raw JSON from S3")
    except s3_client.exceptions.NoSuchKey:
        error_msg = f"File not found: s3://{source_bucket}/{file_key}"
        print(error_msg)
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'File not found', 'file': file_key})
        }
    except json.JSONDecodeError as e:
        error_msg = f"Invalid JSON format in file: {e}"
        print(error_msg)
        # Buffer malformed data for investigation
        buffer_malformed_data(file_key, raw_data if 'raw_data' in locals() else None, error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Invalid JSON format', 'details': str(e)})
        }
    except Exception as e:
        error_msg = f"Error reading from S3: {e}"
        print(error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'S3 read error: {str(e)}'})
        }

    # -------------------------
    # Transform Data
    # -------------------------
    try:
        transformed_data = transform_weather_data(raw_data)
        print(f"✓ Transformed data for city: {transformed_data['city']}")
    except KeyError as e:
        error_msg = f"Missing required field in API response: {e}"
        print(error_msg)
        buffer_malformed_data(file_key, raw_data, error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Transformation error - missing field', 'details': str(e)})
        }
    except Exception as e:
        error_msg = f"Error transforming data: {e}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        buffer_malformed_data(file_key, raw_data, error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f'Transformation error: {str(e)}'})
        }

    # -------------------------
    # Attempt DB Insert with Retry Logic
    # -------------------------
    api_response_time = int((time.time() - start_time) * 1000)
    max_retries = 3
    retry_count = 0
    last_error = None

    while retry_count < max_retries:
        try:
            inserted = load_to_database(transformed_data, api_response_time)
            if inserted:
                print(f"✓ Successfully loaded data for {transformed_data['city']} into database")
                
                # Success - return immediately
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': f'Successfully processed {transformed_data["city"]}',
                        'file': file_key,
                        'retry_count': retry_count
                    })
                }
            else:
                raise Exception("No rows inserted — possible duplicate or constraint violation")
                
        except pg8000.dbapi.InterfaceError as e:
            # Database connection error - likely DB is down
            last_error = f"Database connection failed: {e}"
            print(f"⚠️ Attempt {retry_count + 1}/{max_retries} - {last_error}")
            retry_count += 1
            if retry_count < max_retries:
                time.sleep(2 ** retry_count)  # Exponential backoff: 2s, 4s, 8s
            
        except pg8000.dbapi.DatabaseError as e:
            # Database error (constraint violation, data type mismatch, etc.)
            last_error = f"Database error: {e}"
            print(f"✗ Database error (not retrying): {last_error}")
            # Don't retry for data errors - buffer immediately
            break
            
        except Exception as e:
            # Other unexpected errors
            last_error = f"Unexpected error: {e}"
            print(f"✗ Unexpected error: {last_error}")
            import traceback
            traceback.print_exc()
            break

    # -------------------------
    # If we get here, all retries failed or there was a non-retryable error
    # Buffer the clean data to S3 for later retry
    # -------------------------
    print(f"⚠️ Database unavailable after {retry_count} attempts — buffering clean data to S3")
    
    # Create organized folder structure: clean/buffered/YYYY/MM/DD/uuid.json
    buffer_key = f"{CLEAN_FOLDER}buffered/{datetime.now(timezone.utc).strftime('%Y/%m/%d')}/{uuid.uuid4()}.json"
    buffer_metadata = {
        'city': transformed_data['city'],
        'timestamp': transformed_data['observation_timestamp'].isoformat() if transformed_data.get('observation_timestamp') else 'unknown',
        'retry_count': str(retry_count),
        'last_error': last_error[:1000] if last_error else 'Unknown',
        'source_file': file_key
    }
    
    try:
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=buffer_key,
            Body=json.dumps(transformed_data, default=str),
            Metadata=buffer_metadata,
            ContentType='application/json'
        )
        print(f"✓ Buffered data to s3://{S3_BUCKET}/{buffer_key}")
        
        return {
            'statusCode': 202,  # 202 Accepted - processing deferred
            'body': json.dumps({
                'message': 'Database unavailable — data buffered for retry',
                'source_file': file_key,
                'buffer_location': f's3://{S3_BUCKET}/{buffer_key}',
                'retry_count': retry_count,
                'error': last_error
            })
        }
        
    except Exception as s3_error:
        error_msg = f"✗ CRITICAL: Failed to buffer data to S3: {s3_error}"
        print(error_msg)
        
        # Last resort - log to CloudWatch (data will be in logs)
        print("=== FAILED DATA (for recovery) ===")
        print(json.dumps(transformed_data, default=str))
        print("=== END FAILED DATA ===")
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Database unavailable and buffer failed',
                'db_error': last_error,
                's3_error': str(s3_error),
                'data_logged': True  # Data is in CloudWatch Logs
            })
        }


# ===================================================================
# Helper Functions
# ===================================================================
def buffer_malformed_data(file_key, raw_data, error_msg):
    """Buffer malformed/invalid data for investigation"""
    # Create organized folder structure: clean/malformed/YYYY/MM/DD/uuid.json
    buffer_key = f"{CLEAN_FOLDER}malformed/{datetime.now(timezone.utc).strftime('%Y/%m/%d')}/{uuid.uuid4()}.json"
    
    try:
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=buffer_key,
            Body=json.dumps({
                'source_file': file_key,
                'error': error_msg,
                'raw_data': raw_data,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }, default=str),
            Metadata={
                'error_type': 'malformed_data',
                'source_file': file_key
            },
            ContentType='application/json'
        )
        print(f"✓ Buffered malformed data to s3://{S3_BUCKET}/{buffer_key}")
    except Exception as e:
        print(f"✗ Failed to buffer malformed data: {e}")


# ===================================================================
# Transformation Logic
# ===================================================================
def transform_weather_data(raw_data):
    """Transform raw API data into database-ready format"""
    city = raw_data.get('name', 'Unknown')
    country = raw_data.get('sys', {}).get('country')
    coord = raw_data.get('coord', {})
    latitude = coord.get('lat')
    longitude = coord.get('lon')
    dt_unix = raw_data.get('dt')
    observation_timestamp = (
        datetime.fromtimestamp(dt_unix, tz=timezone.utc) if dt_unix else None
    )
    
    # Main weather data
    main = raw_data.get('main', {})
    temp_c = main.get('temp')
    feels_like_c = main.get('feels_like')
    temp_f = celsius_to_fahrenheit(temp_c)
    feels_like_f = celsius_to_fahrenheit(feels_like_c)
    
    # Weather description
    weather = raw_data.get('weather', [{}])[0]
    
    # System data (sunrise/sunset)
    sys = raw_data.get('sys', {})
    sunrise = datetime.fromtimestamp(sys.get('sunrise'), tz=timezone.utc) if sys.get('sunrise') else None
    sunset = datetime.fromtimestamp(sys.get('sunset'), tz=timezone.utc) if sys.get('sunset') else None
    
    # Wind data
    wind = raw_data.get('wind', {})
    
    # Cloud data
    clouds = raw_data.get('clouds', {})

    return {
        # Basic info
        'city': city,
        'country': country,
        'latitude': latitude,
        'longitude': longitude,
        'observation_timestamp': observation_timestamp,
        'fetch_timestamp': datetime.now(timezone.utc),
        
        # Weather observations
        'temperature_celsius': temp_c,
        'temperature_fahrenheit': temp_f,
        'feels_like_celsius': feels_like_c,
        'feels_like_fahrenheit': feels_like_f,
        'humidity': main.get('humidity'),
        'pressure': main.get('pressure'),
        'weather_main': weather.get('main'),
        'weather_description': weather.get('description'),
        
        # Weather details
        'temp_min_celsius': main.get('temp_min'),
        'temp_max_celsius': main.get('temp_max'),
        'sea_level_pressure': main.get('sea_level'),
        'ground_level_pressure': main.get('grnd_level'),
        'wind_speed': wind.get('speed'),
        'wind_direction': wind.get('deg'),
        'wind_gust': wind.get('gust'),
        'cloudiness': clouds.get('all'),
        'visibility': raw_data.get('visibility'),
        'weather_icon': weather.get('icon'),
        'sunrise': sunrise,
        'sunset': sunset
    }


def celsius_to_fahrenheit(celsius):
    if celsius is None:
        return None
    return round((celsius * 9 / 5) + 32, 2)


# ===================================================================
# Database Loader
# ===================================================================
def load_to_database(data, api_response_time):
    """
    Insert weather data into PostgreSQL.
    Returns True if insert committed successfully, False otherwise.
    Raises exceptions for errors.
    """
    conn = pg8000.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT,
        timeout=10
    )

    cursor = conn.cursor()
    city_id = None
    observation_id = None
    has_nulls = False
    validation_passed = True
    error_message = None
    
    try:
        # Insert or update city
        cursor.execute("""
            INSERT INTO cities (city_name, country_code, latitude, longitude)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (city_name) DO UPDATE
            SET latitude = EXCLUDED.latitude,
                longitude = EXCLUDED.longitude,
                updated_at = NOW()
            RETURNING city_id
        """, (
            data['city'],
            data['country'],
            data['latitude'],
            data['longitude']
        ))
        city_id = cursor.fetchone()[0]

        # Insert weather observation
        cursor.execute("""
            INSERT INTO weather_observations (
                city_id, observation_timestamp, fetch_timestamp,
                temperature_celsius, temperature_fahrenheit,
                feels_like_celsius, feels_like_fahrenheit,
                humidity, pressure,
                weather_main, weather_description
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (city_id, observation_timestamp) DO NOTHING
            RETURNING observation_id
        """, (
            city_id,
            data['observation_timestamp'],
            data['fetch_timestamp'],
            data['temperature_celsius'],
            data['temperature_fahrenheit'],
            data['feels_like_celsius'],
            data['feels_like_fahrenheit'],
            data['humidity'],
            data['pressure'],
            data['weather_main'],
            data['weather_description']
        ))
        
        result = cursor.fetchone()
        if result:
            observation_id = result[0]
            
            # Insert weather details
            cursor.execute("""
                INSERT INTO weather_details (
                    observation_id,
                    temp_min_celsius,
                    temp_max_celsius,
                    sea_level_pressure,
                    ground_level_pressure,
                    wind_speed,
                    wind_direction,
                    wind_gust,
                    cloudiness,
                    visibility,
                    weather_icon,
                    sunrise,
                    sunset
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                observation_id,
                data.get('temp_min_celsius'),
                data.get('temp_max_celsius'),
                data.get('sea_level_pressure'),
                data.get('ground_level_pressure'),
                data.get('wind_speed'),
                data.get('wind_direction'),
                data.get('wind_gust'),
                data.get('cloudiness'),
                data.get('visibility'),
                data.get('weather_icon'),
                data.get('sunrise'),
                data.get('sunset')
            ))
            
            # Check for NULL values
            critical_fields = [
                data.get('temperature_celsius'),
                data.get('humidity'),
                data.get('weather_description')
            ]
            has_nulls = any(field is None for field in critical_fields)
            
            # Calculate data completeness score
            all_fields = [
                data.get('temperature_celsius'),
                data.get('temperature_fahrenheit'),
                data.get('feels_like_celsius'),
                data.get('feels_like_fahrenheit'),
                data.get('humidity'),
                data.get('pressure'),
                data.get('weather_main'),
                data.get('weather_description'),
                data.get('wind_speed'),
                data.get('wind_direction'),
                data.get('cloudiness'),
                data.get('visibility')
            ]
            non_null_count = sum(1 for field in all_fields if field is not None)
            data_completeness_score = round(non_null_count / len(all_fields), 2)
            
            # Insert data quality log
            cursor.execute("""
                INSERT INTO data_quality_log (
                    city_id,
                    observation_id,
                    fetch_timestamp,
                    api_response_time_ms,
                    data_completeness_score,
                    has_nulls,
                    validation_passed,
                    error_message
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                city_id,
                observation_id,
                data['fetch_timestamp'],
                api_response_time,
                data_completeness_score,
                has_nulls,
                validation_passed,
                error_message
            ))
        else:
            # Duplicate
            print(f"ℹ️ Duplicate observation for {data['city']} at {data['observation_timestamp']}")
            conn.commit()
            return False

        conn.commit()
        return True

    except Exception as e:
        conn.rollback()
        
        # Log the error in data_quality_log if we have city_id
        if city_id:
            try:
                cursor.execute("""
                    INSERT INTO data_quality_log (
                        city_id,
                        observation_id,
                        fetch_timestamp,
                        api_response_time_ms,
                        data_completeness_score,
                        has_nulls,
                        validation_passed,
                        error_message
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    city_id,
                    observation_id,
                    data['fetch_timestamp'],
                    api_response_time,
                    0.0,
                    True,
                    False,
                    str(e)[:500]
                ))
                conn.commit()
            except:
                pass
        
        raise

    finally:
        cursor.close()
        conn.close()