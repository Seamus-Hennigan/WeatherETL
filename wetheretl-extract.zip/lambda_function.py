import json
import requests
from datetime import datetime, timezone
import boto3

def lambda_handler(event, context):
    """
    Fetches weather data for multiple cities and saves to S3.
    """
    
    # Configuration
    API_KEY = "4f52103906466f95ed4587af36344b09"
    CITIES = ["London", "New York", "Tokyo", "Sydney", "Paris"] 
    BUCKET_NAME = "wetheretl-data-raw-sch"
    
    print(f"Starting weather collection for {len(CITIES)} cities")
    
    # Track results
    successful_cities = []
    failed_cities = []
    
    # Create S3 client once (more efficient)
    s3_client = boto3.client('s3')
    
    # Loop through each city
    for city in CITIES:
        try:
            print(f"\n--- Processing {city} ---")
            
            # Fetch weather data
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # Add metadata
            fetch_time = datetime.now(timezone.utc)
            data['fetch_timestamp'] = fetch_time.isoformat()
            data['fetch_source'] = 'weatheretl-lambda'
            
            print(f"Temperature in {city}: {data['main']['temp']}°C")
            print(f"Condition: {data['weather'][0]['description']}")
            
            # Create filename with timestamp
            timestamp = fetch_time.strftime('%Y-%m-%d-%H-%M-%S')
            filename = f"raw/{city.lower().replace(' ', '-')}-{timestamp}.json"
            
            # Save to S3
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=filename,
                Body=json.dumps(data, indent=2),
                ContentType='application/json'
            )
            
            print(f"✓ Successfully saved {city} to S3")
            successful_cities.append(city)
            
        except Exception as e:
            print(f"✗ ERROR with {city}: {str(e)}")
            failed_cities.append(city)
            # Continue to next city even if this one fails
    
    # Summary
    print(f"\n=== SUMMARY ===")
    print(f"Successful: {len(successful_cities)}/{len(CITIES)} cities")
    print(f"Success: {successful_cities}")
    if failed_cities:
        print(f"Failed: {failed_cities}")
    
    return {
        'statusCode': 200 if len(successful_cities) > 0 else 500,
        'body': json.dumps({
            'message': f'Collected weather for {len(successful_cities)}/{len(CITIES)} cities',
            'successful': successful_cities,
            'failed': failed_cities
        })
    }
